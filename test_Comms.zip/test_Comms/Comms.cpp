#include "Arduino.h"
#include "Comms.h"

Comms::Comms(char* divider, String buffer)
{
    _divider = divider;
    _buffer = buffer;
}

void Comms::sendMessageToPython(const char* message)
{
  // Serial.println(); // buffer line print
  Serial.print(_buffer); // buffer characters
  Serial.print(_divider);
  Serial.print(message);
  Serial.print(_divider);
  Serial.println(_buffer); // buffer characters
}

void Comms::sendArrayToPython(const char* varname, int* arr, int a, int b, int c)
{
  Serial.print(_buffer); // buffer characters
  Serial.print(_divider);
  Serial.print(varname);
  Serial.print(_divider);
  Serial.print("[");
  for (int i = 0; i < a*b*c; i++) {
    Serial.print(arr[i]);
    if (i < (a*b*c)-1){
      Serial.print(", ");
    }
    else{
      Serial.print("]");
    }
  }
  Serial.print(_divider);
  Serial.print("[");
  Serial.print(a);
  Serial.print(",");
  Serial.print(b);
  Serial.print(",");
  Serial.print(c);
  Serial.print("]");
  Serial.println(_buffer);
}

void Comms::sendMessageWithVarToPython(const char* message, int var)
{
  // Serial.println(); // buffer line print
  Serial.print(_buffer); // buffer characters
  Serial.print(_divider);
  Serial.print(message);
  Serial.print(_divider);
  Serial.print(var);
  Serial.print(_divider);
  Serial.println(_buffer); // buffer characters
}

CommsRecieve::CommsRecieve() {
    String names[num_params] = {"ETA", "GMN", "ALF", "EPO", "MES", "NMS", "NSR", "NTR", "NEG", "NDR", "NDS"}; // set of parameter names
    for (int i = 0; i<num_params; i++) {
        param_names[i] = names[i];
        param_names[i] = "";
    }
}

void CommsRecieve::printParameters() {
    for (int i =0; i < num_params; i++) {
        Serial.print(param_names[i]);
        Serial.print(":");
        Serial.print(params_value[i]);
    }
}

void CommsRecieve::recieveParameters() {
    Serial.println("Code is ready to reieve parameters from Python");
    int param_idx;
    
    int num_recieved = 0;
    
    while (num_recieved < num_params) {
        if (Serial.available()) {
            codon =  Serial.readStringUntil(';');
            param_idx = findInArray(codon);
            
            if (param_idx >= 0) {
                params_value[param_idx] = Serial.readStringUntil(';').toInt();
                Serial.print(param_names[param_idx]);
                Serial.print(": ");
                Serial.println(params_value[param_idx]);
                Serial.print(';');
                num_recieved++;
              } else {
                Serial.print("Invalid Codon, need more param values;");
              }
            }
        }
    Serial.println("Recieved all of the parameters;");
}

int CommsRecieve::findInArray(String elem) {
    for (int idx = 0; idx < num_params; idx++) {
        if (elem.equals(param_names[idx])) {
            return idx;
        }
    }
    return -1;
}
