#include <Arduino.h>
#ifndef Comms_h
#define Comms_h

class Comms{

public:
    Comms(char* divider, String buffer);
    void sendMessageToPython(const char* message);
    void sendArrayToPython(const char* varname, int* arr, int a, int b, int c);
    void sendMessageWithVarToPython(const char* message, int var);
    // void receiveDataFromPython
    // void receiveMessageFromPython

private:
    char* _divider;
    String _buffer;
};

class CommsReceive {
    
public:
    CommsReceive();
    void receiveParameters();
    void printParameters();

private:
    String codon;
    static const int num_params = 11;
    String param_names[num_params];
    int params_value[num_params];
    
    int findInArray(String elem);
};

#endif
