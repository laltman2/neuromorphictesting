#include <Arduino.h>
#ifndef Comms_h
#define Comms_h


const int max_num_params = 50;

class Comms{

public:

    Comms(char* divider, String buffer);

    void sendMessageToPython(const char* message);
    void sendArrayToPython(const char* varname, int* arr, int a, int b, int c);   
    void sendMessageWithVarToPython(const char* message, int var);

    void receiveParameters();
    void printParameters(); 

    void addParameters();

private:
    char* _divider;
    String _buffer;

    String codon;
    String param_names[max_num_params];
    int params_value[max_num_params];
    int num_params;
    
    int findInArray(String elem);

};

#endif
