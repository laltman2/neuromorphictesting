#include "Arduino.h"
#include "Comms.h"

Comms::Comms(char* divider, String buffer)
{
    _divider = divider;
    _buffer = buffer;
    num_params=0;

    // addParameters("ETA;SPEED;ALF;EPO;MES;NMS;NSR;NTR;NEG;NDR;NDS;");

}

void Comms::sendMessageToPython(const char* message) 
{
  // Serial.println(); // buffer line print
  Serial.print(_buffer); // buffer characters
  Serial.print(_divider);
  Serial.print(message);
  Serial.print(_divider);
  Serial.println(_buffer); // buffer characters
}

void Comms::sendArrayToPython(const char* varname, int* arr, int a, int b, int c)
{
  Serial.print(_buffer); // buffer characters
  Serial.print(_divider);
  Serial.print(varname);
  Serial.print(_divider);
  Serial.print("[");
  for (int i = 0; i < a*b*c; i++) {
    Serial.print(arr[i]);
    if (i < (a*b*c)-1){
      Serial.print(", ");
    }
    else{
      Serial.print("]");
    }
  }
  Serial.print(_divider);
  Serial.print("[");
  Serial.print(a);
  Serial.print(",");
  Serial.print(b);
  Serial.print(",");
  Serial.print(c);
  Serial.print("]");
  Serial.println(_buffer);
}

void Comms::sendMessageWithVarToPython(const char* message, int var)
{
  // Serial.println(); // buffer line print
  Serial.print(_buffer); // buffer characters
  Serial.print(_divider);
  Serial.print(message);
  Serial.print(_divider);
  Serial.print(var);
  Serial.print(_divider);
  Serial.println(_buffer); // buffer characters
}

void Comms::printParameters() {
    for (int i =0; i < num_params; i++) {
        Serial.print(param_names[i]);
        Serial.print(":");
        Serial.println(params_value[i]);
    }
}

void Comms::receiveParameters() {
    int param_idx;
    
    int num_received = 0;
    
    while (num_received < num_params) {
        if (Serial.available()) {
            codon =  Serial.readStringUntil(';');
            param_idx = findInArray(codon);
            
            if (param_idx >= 0) {
                params_value[param_idx] = Serial.readStringUntil(';').toInt();
                Serial.print(param_names[param_idx]);
                Serial.print(": ");
                Serial.println(params_value[param_idx]);
                Serial.print(';');
                num_received++;
              } else {
                Serial.print("Invalid Codon, need more param values;");
              }
            }
        }
}

void Comms::addParameters() {
    num_params = 0;

    while (Serial.available()) {  
        String param = Serial.readStringUntil(';');
        if (param.length() > 0) { 
            param_names[num_params] = param; 
            num_params++;
        }
    }
}

int Comms::findInArray(String elem) {
    for (int idx = 0; idx < num_params; idx++) {
        if (elem.equals(param_names[idx])) {
            return idx;
        }
    }
    return -1;
}
